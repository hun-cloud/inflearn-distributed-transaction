package com.example.monolithic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonolithicApplicationTests {

	@Test
	void contextLoads() {
	}

}
